import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from '../search-service.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddFavouriteComponent } from '../add-favourite/add-favourite.component';
import { Store, select } from '@ngrx/store';
import { getSearchResult } from '../search.actions';
import { Observable } from 'rxjs';
import { State } from '../search.reducer';

@Component({
  selector: 'app-search-image',
  templateUrl: './search-image.component.html',
  styleUrls: ['./search-image.component.css'],
})
export class SearchImageComponent implements OnInit {
  response: any;
  favImage = [];
  image: any;
  display: boolean = false;
  isDisable: boolean = true;
  state$: Observable<any>;

  constructor(
    private dialog: MatDialog,
    private store: Store<{ state: State }>
  ) {
    this.state$ = store.pipe(select('state'));
    this.state$.subscribe((res) => {
      this.response = res.searchResult;
    });
  }
  addSelected(i): void {
    this.isDisable = false;
    const dialogRef = this.dialog.open(AddFavouriteComponent, {
      width: '500px',
      height: '200px',
      data: this.response[i],
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
    });
  }

  search(query) {
    this.store.dispatch(getSearchResult({ query }));
  }

  ngOnInit(): void {}
}
