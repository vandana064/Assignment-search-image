import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from '../search-service.service';
import { Store, select } from '@ngrx/store';
import { State } from '../search.reducer';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-saved-images',
  templateUrl: './saved-images.component.html',
  styleUrls: ['./saved-images.component.css'],
})
export class SavedImagesComponent {
  favImage: any;
  state$: Observable<any>;

  constructor(private store: Store<{ state: State }>) {
    this.state$ = store.pipe(select('state'));
    this.state$.subscribe((res) => {
      if (res.favorites.length > 0) {
        this.favImage = res.favorites;
        this.favImage = [...new Set(this.favImage)];
      }
    });
  }

  downloadFav(i) {
    this.toDataURL(this.favImage[i].imageUrl, function (dataUrl) {
      console.log(dataUrl);
      var a = document.createElement('a'); //Create <a>
      a.href = dataUrl; //Image Base64 Goes here
      a.download = 'Image.png'; //File name Here
      a.click();
    });
  }
  toDataURL(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        callback(reader.result);
      };
      reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.send();
  }
}
