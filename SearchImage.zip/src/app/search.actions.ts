import { createAction, props } from '@ngrx/store';

export const getSearchResult = createAction(
  '[Search Component] get',
  props<{ query: string }>()
);
export const getSearchSuccess = createAction(
  '[Search Component] success',
  props<{ results: any[] }>()
);
export const addFavorite = createAction(
  '[Search Component] add',
  props<{ favorite: any }>()
);
