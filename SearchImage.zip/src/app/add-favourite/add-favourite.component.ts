import { Component, OnInit, Inject } from '@angular/core';
import { SearchServiceService } from '../search-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Store, select } from '@ngrx/store';
import { State } from '../search.reducer';
import { Observable } from 'rxjs';
import { addFavorite } from '../search.actions';

@Component({
  selector: 'app-add-favourite',
  templateUrl: './add-favourite.component.html',
  styleUrls: ['./add-favourite.component.css'],
})
export class AddFavouriteComponent {
  listName: any = '';
  list: string = '';
  data: any;
  link: String;
  favImages: any;
  pageUrl: any;
  imageName: any;
  val1: any;
  display: boolean;
  list1: any;
  listValues: any = [];
  list2: any;
  lists = [];
  object: { name: any; imageUrl: any };
  showInput: boolean;
  favList: boolean;
  favLists: any[];
  state$: Observable<any>;
  constructor(
    private store: Store<{ state: State }>,
    public snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<AddFavouriteComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.data = data;
    //this.link = data.pageURL
    this.pageUrl = data.user.name;
    this.imageName = data.alt_description;

    console.log(data);
    this.state$ = store.pipe(select('state'));
    this.state$.subscribe((res) => {
      if (res.favorites.length > 0) {
        this.favList = true;
        this.favLists = [...new Set(res.favorites.map((x) => x.name))];
      }
    });
  }

  addSelected() {
    this.store.dispatch(addFavorite({ favorite: this.data }));
  }

  onRadioBtnClick(list) {
    this.val1 = list;
  }
  addToFavourities(listName) {
    console.log(this.list);
    this.object = { name: this.listName, imageUrl: this.data.urls.small };
    this.store.dispatch(addFavorite({ favorite: this.object }));
  }
  addToExisting(listName) {
    console.log(listName);
    this.object = { name: listName, imageUrl: this.data.urls.small };
    this.store.dispatch(addFavorite({ favorite: this.object }));
  }
  addNewList() {
    this.showInput = true;
  }
}
