import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import { map, exhaustMap, catchError } from 'rxjs/operators';
import { SearchServiceService } from './search-service.service';
import { getSearchResult, getSearchSuccess } from './search.actions';

@Injectable()
export class SearchEffects {
  constructor(
    private actions$: Actions,
    private searchService: SearchServiceService
  ) {}

  loadMovies$ = createEffect(() =>
    this.actions$.pipe(
      ofType(getSearchResult),
      exhaustMap((action: any) =>
        this.searchService.getSearchResult(action.query).pipe(
          map((response: any) =>
            getSearchSuccess({ results: response.results })
          ),
          catchError(() => EMPTY)
        )
      )
    )
  );
}
