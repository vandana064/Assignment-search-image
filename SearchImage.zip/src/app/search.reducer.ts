import { createReducer, on } from '@ngrx/store';
import {
  getSearchResult,
  addFavorite,
  getSearchSuccess,
} from './search.actions';

export interface State {
  searchResult: any[];
  favorites: any[];
}

export const initialState: State = {
  searchResult: [],
  favorites: [],
};

const _searchReducer = createReducer(
  initialState,
  on(getSearchResult, (state) => state),
  on(getSearchSuccess, (state, { results }) => ({
    ...state,
    searchResult: results,
  })),
  on(addFavorite, (state, { favorite }) => {
    console.log(state, favorite);
    return {
      ...state,
      favorites: [...state.favorites, favorite],
    };
  })
);

export function searchReducer(state: State | undefined, action: any) {
  return _searchReducer(state, action);
}
